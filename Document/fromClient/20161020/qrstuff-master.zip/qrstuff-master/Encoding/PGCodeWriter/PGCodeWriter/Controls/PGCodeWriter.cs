﻿using System;
using Xamarin.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PGCodeWriter
{
	public class PGCodeWriter :PGCodeAbstract
	{
		public string UUID
		{
			get { return (string)GetValue(UUIDProperty); }
			set
			{
				if (Regex.IsMatch(value,"^[0-9A-F]{8}-[0-9A-F]{4}-[4][0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$",RegexOptions.IgnoreCase))
				{
					SetValue(UUIDProperty, value);
				}
				else {
					SetValue(UUIDProperty, null);
				}
			}
		}
		public bool image
		{
			get; set; 
		}
		public static readonly BindableProperty UUIDProperty = BindableProperty.Create("UUID", typeof(string), typeof(PGCodeWriter), "");
		
	}
}

