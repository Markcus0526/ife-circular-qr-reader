﻿using System;
using PGCodeWriter;
using PGCodeWriter.iOS;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
using UIKit;
using CoreGraphics;
using CoreAnimation;
using System.Linq;
using System.Collections.Generic;
using Foundation;

[assembly: ExportRenderer (typeof(PGCodeWriter.PGCodeWriter), typeof(PGCodeViewerRenderer))]

namespace PGCodeWriter.iOS
{
	public class PGCodeViewerRenderer : VisualElementRenderer<PGCodeWriter>
	{
		private string lastUUID=null;
		private string lastUUIDBinaryEncoded = null;
		private CALayer mainLayer,maskLayer;
		private CAGradientLayer gradientLayer;
		float pi = (float)Math.PI;
		float startLineDiff = 2f;
		float lineSeparation = 20f;
		float lineSize = 2.2f;
		int bitsPerChar = 5;
		int accumulatedUUIDParseIdx = 0;
		int numberValPadding = 5;
		int charValPadding = 8;
		float miniCircleSpacingX = 10;
		UIColor leftColor = UIColor.FromRGB(135,124,223);
		UIColor rightColor = UIColor.FromRGB(125,177,220);
		Dictionary<int, List<ArcData>> listOfArcs = new Dictionary<int, List<ArcData>>();
		Dictionary<int, List<ArcData>> listOfRightArcs = new Dictionary<int, List<ArcData>>();

		public PGCodeViewerRenderer ()
		{
		}

		protected override void OnElementChanged (ElementChangedEventArgs<PGCodeWriter> e)
		{
			base.OnElementChanged (e);
			if (e.NewElement != null) {
				this.BackgroundColor = UIColor.White;
				SetNeedsDisplay();
			}
		}

		protected override void OnElementPropertyChanged (object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			base.OnElementPropertyChanged (sender, e);
			this.BackgroundColor = UIColor.White;
			SetNeedsDisplay();
		}

		//string t2 = "";
		public override void Draw(CGRect rect)
		{
			base.Draw(rect);
			if (Element != null)
			{
				if (lastUUID != Element.UUID && Frame.Width > 0 && Frame.Height > 0)
				{
					lastUUID = Element.UUID;
					if (mainLayer != null)
					{
						mainLayer.RemoveFromSuperLayer();
					}
					if (gradientLayer != null)
					{
						gradientLayer.RemoveFromSuperLayer();
					}
					if (!string.IsNullOrEmpty(lastUUID))
					{
						lastUUIDBinaryEncoded = EncodeUUIDToBinary();
						//Console.WriteLine(lastUUIDBinaryEncoded);
						accumulatedUUIDParseIdx = 0;
						mainLayer = maskLayer = new CALayer();
						gradientLayer = new CAGradientLayer();
						gradientLayer.Frame = mainLayer.Frame = maskLayer.Frame = new CGRect(0, 0, Frame.Width, Frame.Height);
						InitializeArcAnglesList();
						DrawPatternRecognition(2);
						//t2 = "";
						DrawCircleCode(1);
						DrawCircleCode(2);
						DrawCircleCode(3);
						//Console.WriteLine(t2);
						Layer.AddSublayer(mainLayer);
						//the gradient
						gradientLayer.StartPoint = new CGPoint(0, 0.5f);
						gradientLayer.EndPoint = new CGPoint(1, 0.5f);
						var colors = new CGColor[] { leftColor.CGColor, rightColor.CGColor };
						gradientLayer.Colors = colors;
						gradientLayer.Mask = maskLayer;
						Layer.AddSublayer(gradientLayer);
					}
				}
			}
		}

		void InitializeArcAnglesList()
		{
			listOfArcs = new Dictionary<int, List<ArcData>>();
			listOfRightArcs = new Dictionary<int, List<ArcData>>();
			var keys = Element.MiniDotsAngles.Keys.OrderBy(x => x);
			foreach (int line in keys)
			{
				//convert the miniCircleSpacingX to an angle
				var minSize = (float)Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
				float difference = startLineDiff + (line - 1) * lineSeparation;
				minSize -= difference;
				minSize -= minSize * lineSize / 200;
				var radius = minSize / 2;
				var miniCircleSpacingAngle = XDistanceValToAngleDegrees(miniCircleSpacingX, radius);
				var padding = GetArcPadding(difference, radius);
				//fill the listOfArcs based on the dots angles specified on miniDots
				var theArcs = new List<ArcData>();
				var miniDots = Element.MiniDotsAngles[line];

				SetLineArc(theArcs, miniCircleSpacingAngle, 0, 120, padding, padding, miniDots);
				SetLineArc(theArcs, miniCircleSpacingAngle, 120, 240, padding, padding, miniDots);
				SetLineArc(theArcs, miniCircleSpacingAngle, 240, 360, padding, padding, miniDots);
				listOfArcs[line] = theArcs;
			}
		}

		void SetLineArc(List<ArcData> sideArcList, float miniDotSpacing, float minArcAngle, float maxArcAngle, float arcPaddingLeft, float arcPaddingRight, List<float> dotsList)
		{
			var theList = dotsList.OrderBy(x => x).ToList();
			float lastArcStartAngle = minArcAngle+ arcPaddingLeft;
			float lastArcEndAngle = maxArcAngle-arcPaddingRight;
			for (int i = 0; i < theList.Count; i++)
			{
				if (theList[i] > maxArcAngle)
				{
					if (i > 0 && theList[i-1] + miniDotSpacing > minArcAngle + arcPaddingLeft)
					{
						lastArcStartAngle = theList[i-1] + miniDotSpacing;
					}
					if (theList[i] - miniDotSpacing < maxArcAngle - arcPaddingRight)
					{
						lastArcEndAngle = theList[i] - miniDotSpacing;
					}
					break;
				}
				float startDegrees = minArcAngle;
				if (i > 0 && theList[i - 1] + miniDotSpacing>minArcAngle)
				{
					startDegrees = theList[i - 1] + miniDotSpacing;
				}
				float endDegrees = theList[i]- miniDotSpacing;
				if (startDegrees >= minArcAngle && endDegrees <= maxArcAngle && endDegrees>startDegrees)
				{
					var minimumRequiredAngle = minArcAngle + arcPaddingLeft;
					if (startDegrees < minimumRequiredAngle)
					{
						startDegrees = minimumRequiredAngle;
					}
					var maximumRequiredAngle = maxArcAngle - arcPaddingRight;
					if (endDegrees > maximumRequiredAngle)
					{
						endDegrees = maximumRequiredAngle;
					}
					sideArcList.Add(new ArcData(startDegrees, endDegrees));
				}
				if (theList[i] > minArcAngle && theList[i] + miniDotSpacing>minArcAngle + arcPaddingLeft)
				{
					lastArcStartAngle = theList[i] + miniDotSpacing;
				}
			}
			//Add the last arc
			if (lastArcEndAngle>lastArcStartAngle)
			{
				sideArcList.Add(new ArcData(lastArcStartAngle, lastArcEndAngle));
			}
		}

		private void DrawPatternRecognition(int lineNumber)
		{
			var minSize = Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
			float radius = (float)(minSize * 13f / 200) / 2;
			DrawPatternBigCircleAtAngle(120,2,radius,leftColor);
			DrawPatternBigCircleAtAngle(240,2, radius,rightColor);
			DrawPatternBigCircleAtAngle(0, 2, radius, leftColor);
			//DrawPatternImageAtAngle(0, 2, radius, UIImage.FromBundle("qr_code_logo"));
			var miniDots = Element.MiniDotsAngles;
			var keys = miniDots.Keys.OrderBy(x => x);
			foreach (int line in keys)
			{
				var lineDots = miniDots[line];
				for (int pos = 0; pos < lineDots.Count; pos++)
				{
					var angle = lineDots[pos];
					var color = angle > 180 ? rightColor : leftColor;
					DrawPatternMiniCircleAtAngle(angle, line, color);
				}
			}
		}

		void DrawPatternImageAtAngle(float degrees, int lineNumber, float radius, UIImage img)
		{
			float difference = startLineDiff + (lineNumber - 1) * lineSeparation;
			var minSize = Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height)-difference;
			var lineWidth = (float)minSize * lineSize / 200;
			radius += lineWidth / 2;
			minSize -= lineWidth*1.5f;
			float radians = (degrees + 90) * pi / 180;

			var x = mainLayer.Frame.Width / 2 + Math.Cos(radians) * minSize / 2;
			var y = mainLayer.Frame.Height / 2 - Math.Sin(radians) * minSize / 2;
			var imageLayer = new CALayer();
			imageLayer.Frame = new CGRect(x - radius, y - radius, radius*2, radius*2);
			imageLayer.Contents = img.CGImage;
			mainLayer.AddSublayer(imageLayer);
		}

		void DrawPatternMiniCircleAtAngle(float degrees, int lineNumber, UIColor color1, UIColor color2=null)
		{
			float difference = startLineDiff + (lineNumber - 1) * lineSeparation;
			var minSize = Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
			var radius = (float)minSize * lineSize / 200 * 0.8f;
			float radians = (degrees + 90) * pi / 180;
			var lineWidth = (nfloat)minSize * lineSize / 200;
			minSize -= difference + lineWidth;

			var x = mainLayer.Frame.Width / 2 + Math.Cos(radians) * minSize / 2;
			var y = mainLayer.Frame.Height / 2 - Math.Sin(radians) * minSize / 2;

			var circleLayer = new CAShapeLayer();
			circleLayer.LineWidth = 0;
			circleLayer.Frame = new CGRect(x - radius, y - radius, radius * 2, radius * 2);
			UIBezierPath path = UIBezierPath.FromOval(new CGRect(0, 0, radius * 2, radius * 2));
			circleLayer.Path = path.CGPath;
			circleLayer.FillColor = UIColor.Black.CGColor;
			circleLayer.StrokeColor = UIColor.Clear.CGColor;
			maskLayer.AddSublayer(circleLayer);
		}

		void DrawPatternBigCircleAtAngle(float degrees,int lineNumber, float radius, UIColor color)
		{
			float difference = startLineDiff + (lineNumber - 1) * lineSeparation;
			var minSize = Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
			float radians = (degrees + 90) * pi / 180;
			var lineWidth = (nfloat)minSize * lineSize / 200;
			minSize -= difference+lineWidth*1.5f;

			var x = mainLayer.Frame.Width / 2 + Math.Cos(radians) * minSize / 2;
			var y = mainLayer.Frame.Height / 2 - Math.Sin(radians) * minSize / 2;
			var circleLayer = new CAShapeLayer();
			circleLayer.LineWidth = lineWidth;
			circleLayer.Frame = new CGRect(x-radius,y- radius,radius*2,radius*2);
			UIBezierPath path = UIBezierPath.FromOval(new CGRect(0,0, radius*2, radius*2));
			circleLayer.Path = path.CGPath;
			circleLayer.FillColor = UIColor.Clear.CGColor;
			circleLayer.StrokeColor = UIColor.Black.CGColor;
			maskLayer.AddSublayer(circleLayer);
		}

		private void DrawCircleCode(int lineNumber)
		{
			float difference = startLineDiff + (lineNumber - 1) * lineSeparation;
			var circleLayer = new CAShapeLayer();
			var minSize = Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
			difference = (float)minSize * difference / 200;
			circleLayer.LineWidth = (nfloat)minSize * lineSize / 200;
			circleLayer.LineCap = CAShapeLayer.CapRound;
			circleLayer.CornerRadius = circleLayer.LineWidth / 2;
			minSize -= difference;
			minSize -= circleLayer.LineWidth;
			circleLayer.Frame = mainLayer.Frame;

			UIBezierPath thePath = new UIBezierPath();
			float radius = (float)minSize / 2;
			ConvertUUIDToArcCode(thePath,circleLayer.LineWidth,lineNumber,radius,lineNumber==1?4:3,2);
			circleLayer.Path = thePath.CGPath;
			circleLayer.FillColor = UIColor.Clear.CGColor;
			circleLayer.StrokeColor = UIColor.Black.CGColor;
			maskLayer.AddSublayer(circleLayer);
		}

		private void AddCodedArc(UIBezierPath path, double lineWidth, float difference, int arcIndex, float radius, float minDegAngle, float maxDegAngle)
		{
			if (Element.TotalBitsPerArc.ContainsKey(arcIndex))
			{
				var totalBits = Element.TotalBitsPerArc[arcIndex];
				float onebitSizeAngle = (maxDegAngle - minDegAngle) / totalBits;
				var bitsToEncode = ParseBitsFromUUID(accumulatedUUIDParseIdx, totalBits);
				accumulatedUUIDParseIdx += totalBits;
				float startAngle = minDegAngle;
				//t2 += "| **" + arcIndex + "** | " + bitsToEncode.Length + " | **" + bitsToEncode + "** |\n";
				for (int bitPos = 0; bitPos < bitsToEncode.Length; bitPos++)
				{
					var theBit = bitsToEncode[bitPos];
					if (theBit == '1')
					{
						var bitAngle = startAngle + bitPos * onebitSizeAngle;
						DrawBitColorOnAngle(path, lineWidth, difference, radius, bitAngle, bitAngle + onebitSizeAngle);
					}
				}
			}
			else if (Element.CheckSumArcsOrdered.ContainsKey(arcIndex))
			{
				var totalBitsOnUUID = lastUUIDBinaryEncoded.Length;
				int totalGroupsPerChecksum = totalBitsOnUUID / bitsPerChar / Element.CheckSumArcsOrdered.Count;
				var checkSumOrder = Element.CheckSumArcsOrdered[arcIndex] - 1;
				string sumResultOfBits = BinarySumBitsOnUUID(checkSumOrder * totalGroupsPerChecksum *bitsPerChar, totalGroupsPerChecksum, bitsPerChar);
				//Console.WriteLine(sumResultOfBits);
				//t2 += "   **Sum:**"+ sumResultOfBits + "  \n\n";
				float onebitSizeAngle = (maxDegAngle - minDegAngle) / sumResultOfBits.Length;
				float startAngle = minDegAngle;
				for (int bitPos = 0; bitPos < sumResultOfBits.Length; bitPos++)
				{
					var theBit = sumResultOfBits[bitPos];
					if (theBit == '1')
					{
						var bitAngle = startAngle + bitPos * onebitSizeAngle;
						DrawBitColorOnAngle(path, lineWidth, difference, radius, bitAngle, bitAngle + onebitSizeAngle);
					}
				}
			}
			else {
				DrawBitColorOnAngle(path, lineWidth, difference, radius, minDegAngle, maxDegAngle);
			}
		}

		string BinarySumBitsOnUUID(int startBitIndex, int totalGroups, int totalBitsPerGroup)
		{
			var theBits=ParseBitsFromUUID(startBitIndex, totalGroups *totalBitsPerGroup);
			var bitChunks=Enumerable.Range(0, theBits.Length / totalBitsPerGroup).Select(i => theBits.Substring(i * totalBitsPerGroup, totalBitsPerGroup)).ToList();
			int val = 0;
			for (int i = 0; i < bitChunks.Count; i++)
			{
				//t2 += "   "+bitChunks[i] + "  \n";
				val += Convert.ToInt32(bitChunks[i], 2);
			}
			return Convert.ToString(val, 2).PadLeft(8, '0'); // Add 0's from left
		}

		string EncodeUUIDToBinary()
		{
			var noHiffensUUID = lastUUID.Replace("-", "");
			string result = "";
			//var t = "";
			for (int i = 0; i < noHiffensUUID.Length; i++)
			{
				int encodedCharVal = EncodeChar(noHiffensUUID[i]);
				result += string.Join("", EncodedCharToBitArray(encodedCharVal));

				//t+="| **" + noHiffensUUID[i] + "** | " + Convert.ToInt32(noHiffensUUID[i].ToString(), 16) + " | " + encodedCharVal + " | **" + string.Join("", EncodedCharToBitArray(encodedCharVal))+"** |\n";;

			}
			//Console.WriteLine(t);
			return result;
		}

		int EncodeChar(char theChar)
		{
			if (char.IsNumber(theChar))
			{
				return numberValPadding + (int)char.GetNumericValue(theChar);
			}
			else {
				var charIndex = char.ToUpper(theChar)-65;
				return numberValPadding + 10 + charValPadding + charIndex;
			}
		}

		int[] EncodedCharToBitArray(int encodedCharVal)
		{
			string s = Convert.ToString(encodedCharVal, 2); //Convert to binary in a string

			return s.PadLeft(bitsPerChar, '0') // Add 0's from left
						 .Select(c => int.Parse(c.ToString())) // convert each char to int
						 .ToArray(); // Convert IEnumerable from select to Array
		}

		private void DrawBitColorOnAngle(UIBezierPath path, double lineWidth, float difference, float radius, float minDegAngle, float maxDegAngle)
		{
			float minRadiansAngle = (minDegAngle + 90) * pi / 180;
			float maxRadiansAngle = (maxDegAngle + 90) * pi / 180;

			var x = lineWidth / 2 + difference / 2 + Math.Cos(minRadiansAngle) * radius;
			var y = lineWidth / 2 + difference / 2 - Math.Sin(minRadiansAngle) * radius;
			CGPoint point = new CGPoint(radius + x, radius + y);

			path.MoveTo(point);
			point.X = (nfloat)(radius + lineWidth / 2 + difference / 2);
			point.Y = (nfloat)(radius + lineWidth / 2 + difference / 2);
			path.AddArc(point, radius, pi * 2 - minRadiansAngle, pi * 2 - maxRadiansAngle, false);
		}

		void ConvertUUIDToArcCode(UIBezierPath path, double lineWidth, int lineNumber, float radius, int firstArcChars, int secondArcChars)
		{
			float difference = startLineDiff + (lineNumber - 1) * lineSeparation;
			var theList = listOfArcs[lineNumber];
			var startArcIndex = 1;
			for (int i = 1; i < lineNumber;i++)
			{
				startArcIndex += listOfArcs[i].Count ; // the 3 is the total number of big circles which also split arcs
			}
			for (int i = 0; i < theList.Count; i++)
			{
				var data = theList[i];
				AddCodedArc(path, lineWidth, difference, startArcIndex+i, radius, data.StartDegrees, data.EndDegrees);
				//Console.WriteLine(lineNumber + " / " + (startArcIndex + i));
			}
		}

		string ParseBitsFromUUID(int start, int length)
		{
			return lastUUIDBinaryEncoded.Substring(start, length);
		}

		float GetArcPadding(float difference, float radius)
		{
			var minSize = (float)Math.Min(mainLayer.Frame.Width, mainLayer.Frame.Height);
			float xVal = 0;
			float middleLineDiff = minSize * (startLineDiff + lineSeparation) / 200;
			if (difference == middleLineDiff)
			{
				xVal = minSize * 14 / 200;
			}
			else {
				xVal = minSize * 8 / 200;
			}
			return XDistanceValToAngleDegrees(xVal, radius);
		}

		float XDistanceValToAngleDegrees(float x, float radius)
		{
			return (float)(Math.Asin(x / radius) * 180 / Math.PI);
		}

		private class ArcData {

			public float StartDegrees;
			public float EndDegrees;

			public ArcData(float startDegrees, float endDegrees)
			{
				StartDegrees = startDegrees;
				EndDegrees = endDegrees;
			}
		}
	}
}

