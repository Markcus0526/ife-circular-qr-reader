﻿using System;
using Xamarin.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PGCodeWriter
{
	public abstract class PGCodeAbstract :View
	{
		//angles where the mini dots appear per circle outline
		private Dictionary<int, List<float>> miniDots = new Dictionary<int, List<float>>
		{
			{1,new List<float>(){ 35, 85, 157.5f, 204.5f, 275, 325}},
			{2,new List<float>(){ 65, 180, 295 }},
			{3,new List<float>(){ 45, 154, 205 , 315 }},
		};
		//arc number => total encoded bits
		//the bits are encoded by order which means that the arc 1 has bits 0-7, the arc 2 has bits 7-18, etc
		private Dictionary<int, int> totalBitsPerArc = new Dictionary<int, int>
		{
			{1,7},
			{2,11},
			{3,7},
			{7,7},
			{8,11},
			{9,7},
			{10,14},
			{11,9},
			{12,11},
			{13,11},
			{14,9},
			{15,14},
			{16,7},
			{17,14},
			{21,14},
			{22,7},
		};
		//arc number => checksum order (1 = 1st chain of 40 bits; 2 = 2nd chain of 40 bits; etc)
		private Dictionary<int, int> checkSumArcsOrdered = new Dictionary < int, int>
		{
			{4,1},
			{6,2},
			{18,3},
			{20,4}
		};
		public Dictionary<int, List<float>> MiniDotsAngles {
			get
			{
				return miniDots;
			}
		}
		public Dictionary<int, int> TotalBitsPerArc
		{
			get
			{
				return totalBitsPerArc;
			}
		}
		public Dictionary<int, int> CheckSumArcsOrdered
		{
			get
			{
				return checkSumArcsOrdered;
			}
		}

	}
}

