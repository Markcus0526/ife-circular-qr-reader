﻿using Xamarin.Forms;

namespace PGCodeWriter
{
	public partial class PGCodeWriterPage : ContentPage
	{
		public PGCodeWriterPage()
		{
			InitializeComponent();
			NavigationPage.SetHasNavigationBar(this, false);
			uuidCode.Text = System.Guid.NewGuid().ToString(); //"535c1f8c-3cad-4fc2-8205-69455f1d8bad";
			writer.UUID = uuidCode.Text;
			writer.image = false; 
			submitBtn.Clicked += delegate
			{
				writer.UUID = uuidCode.Text;
			};
			regenBtn.Clicked += delegate
			{
				uuidCode.Text = System.Guid.NewGuid().ToString(); //"535c1f8c-3cad-4fc2-8205-69455f1d8bad";
				writer.UUID = uuidCode.Text;
			};
			imageBtn.Clicked += delegate {
				writer.image = true; // !writer.image; 
				if (!writer.image)
					imageBtn.Text = "With Image";
				else
					imageBtn.Text = "Without Image";
				imageBtn.IsVisible = false; 
			};
		}
	}
}
