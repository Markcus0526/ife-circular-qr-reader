# PoGo QR Code

### Summary

The QR Code algorithm used for PoGo has the intention to encode **v4 UUID's** by converting each **hexadecimal character** of the UUID into a **binary form**. Each bit that results from the conversion will then be **drawn on a specific location** of the QR Code if its value is `1`. If the value is `0`, there will simply be an **empty space on a specific location** of the QR Code.

### The QR Code pattern

When working with QR Codes, we must have in mind that the algorithm to find them **when using images or cameras** will need to **identify the north position of the QR Code**. We can only decode a QR Code when the North position is found, otherwise we do not know from where should we start looking for the encoded bits.
In this case, the following pattern was used to identify the North:

![QR Code Arc numbers](qr_code_pattern.png)

### Encoding Process

Like said before, this QR Code algorithm only works with **v4 UUID's** in **lowercase**. This means that all the strings to encode have these specifications:

* A format of `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` where **x** is any **hexadecimal character in lowercase**
* A total length of **32 characters if we don't count the dashes**

The first thing done to the string is the removal of all dashes, so that it becomes in the format of `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`.
Based on that, we have a total of **16 possible characters** for each position of the string and so, that means that in binary the characters range is **from 0000 to 1111**.
Since **we wanted to avoid** any case where a full string of 0's would give **a result identical to the QR Code Pattern** and since we also **wanted to avoid a QR Code with all arcs filled** (if the string only had `f` characters), we decided that **each character** should have **5 bits instead of 4**. This gives us the possibility to encode 32 characters max but, since we only want 16 and we need to avoid the cases previously specified, we did the following:

* Each character on the string that goes from **0 to 9** will correspond to `x + 5` where `x`is the value of the character in decimal format. Example: `0` would become `5`, `1` would become `6`, etc.
* Each character on the string that goes from **a to f** will correspond to `x + 5 + 8` where `x`is the value of the character in decimal format. Example: `a` (which is `10` in decimal) would become `23`, `b` would become `24`, etc.

The values returned per each character according to the list above will then be converted to **5 bits** and joined together on a single string which will have a length of **32 characters multiplying by 5 bits = 160 bit characters (0 or 1)**
Once all this is done, the bits are distributed on the arcs of the QR Code. Bits that are `1` will **draw part of the arc** and bits that are `0` will **leave an empty space**.
The bits are drawn on the arcs according to their order on the string and according to the order of the arcs.
Here's an image that shows and identifies the order of the arc's:

![QR Code Arc numbers](qr_code_arc_numbers.png)

The arcs that have bits encoded have a specific limit of bits represented, based on the following table:

|            | Total Bits  |
| ---------- |:-----------:|
| **Arc 1** | 7 |
| **Arc 2** | 11 |
| **Arc 3** | 7 |
| **Arc 7** | 7 |
| **Arc 8** | 11 |
| **Arc 9** | 7 |
| **Arc 10** | 14 |
| **Arc 11** | 9 |
| **Arc 12** | 11 |
| **Arc 13** | 11 |
| **Arc 14** | 9 |
| **Arc 15** | 14 |
| **Arc 16** | 7 |
| **Arc 17** | 14 |
| **Arc 21** | 14 |
| **Arc 22** | 7 |
| **Total** | **160** |

There are also **4 arcs** that work as a **checksum**. Each one of those arcs will get **8 groups of 5 bits (representation of each character), sum their values and encode the result of the sum (which is 8 bits in total)**. This way we can be sure if the decode worked well by checking the decoded binary code against the checksums.
The arcs used for the checksums are:

|            | Bit groups encoded (5 bits each)|
| ---------- |:-----------:|
| **Arc 4** | 1 to 8 |
| **Arc 6** | 9 to 16 |
| **Arc 18** | 17 to 24 |
| **Arc 20** | 25 to 32 |

The arcs **19** and **5** have been left untouched.

##### Drawning of the bits on arcs

As said before, a bit of value `1` will draw part of the arc and a value of `0` will keep an empty space.
The amount of the arc that is drawn depends on its size and the total amount of bits that it will represent. So **1 bit draw size = Arc length / total bits represented**.

At last, please notice that **the start and end points of each arc are round** and those round points are **not taken into account on the bit size draw**. This means that **if the bit size is for example 5px**, the total size of the arc part drawn is **5 + X + X** where **X = height of the arc / 2**.
If **2 bits** that are next to each other have the value of `1`, then **the round points are only drawn at the start of the first bit and at the end of the 2nd bit** and so, using the previous example sizes, the **total arc size for those bits would be 5 + 5 + X + X**.

### Example of Encoding

Given the UUID of `535c1f8c-3cad-4fc2-8205-69455f1d8bad`, here's all the process done to encode it on a Pogo QR Code image:

* Check if it is a valid UUID.
* Remove the dashes: `535c1f8c3cad4fc2820569455f1d8bad`.
* Encode each character to binary with the rules of **+5 to decimal value if char 0-9** and **+5 +8 to decimal value if char a-f**:

| Char | Original Decimal Value | Decimal Value after rules |  5 bits string representation  |
| ---------- |:-----------:|:-----------:|:-----------:|
| **5** | 5 | 10 | **01010** |
| **3** | 3 | 8 | **01000** |
| **5** | 5 | 10 | **01010** |
| **c** | 12 | 25 | **11001** |
| **1** | 1 | 6 | **00110** |
| **f** | 15 | 28 | **11100** |
| **8** | 8 | 13 | **01101** |
| **c** | 12 | 25 | **11001** |
| **3** | 3 | 8 | **01000** |
| **c** | 12 | 25 | **11001** |
| **a** | 10 | 23 | **10111** |
| **d** | 13 | 26 | **11010** |
| **4** | 4 | 9 | **01001** |
| **f** | 15 | 28 | **11100** |
| **c** | 12 | 25 | **11001** |
| **2** | 2 | 7 | **00111** |
| **8** | 8 | 13 | **01101** |
| **2** | 2 | 7 | **00111** |
| **0** | 0 | 5 | **00101** |
| **5** | 5 | 10 | **01010** |
| **6** | 6 | 11 | **01011** |
| **9** | 9 | 14 | **01110** |
| **4** | 4 | 9 | **01001** |
| **5** | 5 | 10 | **01010** |
| **5** | 5 | 10 | **01010** |
| **f** | 15 | 28 | **11100** |
| **1** | 1 | 6 | **00110** |
| **d** | 13 | 26 | **11010** |
| **8** | 8 | 13 | **01101** |
| **b** | 11 | 24 | **11000** |
| **a** | 10 | 23 | **10111** |
| **d** | 13 | 26 | **11010** |
* Concatenate all the **5 bits string representation** into a single string representation of **160 bits**: 0101001000010101100100110111000110111001010001100110111110100100111100110010011101101001110010101010010110111001001010100101011100001101101001101110001011111010
* Distribute each part of the string per each arc that encodes these bits, according to their order and to the total amount of bits that they support:

| Arc number | Total Bits | Bits represented |
| ---------- |:----------:|:----------------|
| **1** | 7 | **0101001** |
| **2** | 11 | **00001010110** |
| **3** | 7 | **0100110** |
| **7** | 7 | **1110001** |
| **8** | 11 | **10111001010** |
| **9** | 7 | **0011001** |
| **10** | 14 | **10111110100100** |
| **11** | 9 | **111100110** |
| **12** | 11 | **01001110110** |
| **13** | 11 | **10011100101** |
| **14** | 9 | **010100101** |
| **15** | 14 | **10111001001010** |
| **16** | 7 | **1001010** |
| **17** | 14 | **11100001101101** |
| **21** | 14 | **00110111000101** |
| **22** | 7 | **1111010** |

* Make the checksums for the image
  * **Arc 4**

    01010  
    01000  
    01010  
    11001  
    00110  
    11100  
    01101  
    11001  
    **Sum: 01111101**

  * **Arc 6**

    01000  
    11001  
    10111  
    11010  
    01001  
    11100  
    11001  
    00111  
    **Sum: 10010111**

  * **Arc 18**

    01101  
    00111  
    00101  
    01010  
    01011  
    01110  
    01001  
    01010  
    **Sum: 01001111**

  * **Arc 20**

    01010  
    11100  
    00110  
    11010  
    01101  
    11000  
    10111  
    11010  
    **Sum: 10011100**


##### Final result:

![QR Code Example](qr_code_example.png)

### Decoding ideas:

We need to use OpenCV for the grabbing the codes for the decoding part of the QR Code.
I tried to bind it to a Xamarin project but, without success. Given that, there's an XCode project named **QRCodeXCode** which should be used for the decoding part, together with the code from openCV that will allow us to grab the qr codes from camera.
In order to decode, there must be some way to "cut" the image in parts in order to check the most used color of each arc bit part (after converting the image to a scale of black & white).

**Useful links:**

* http://trinnguyen.com/opencv-for-xamarin-ios/
* http://bytefish.de/blog/extracting_contours_with_opencv/
* http://stackoverflow.com/questions/31384237/how-to-mask-a-video-frame-using-contours-with-opencv-in-python
* http://docs.opencv.org/3.1.0/d4/d73/tutorial_py_contours_begin.html#gsc.tab=0
